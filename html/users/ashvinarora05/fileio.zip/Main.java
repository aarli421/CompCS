import java.util.Scanner;

class Main {
  public static void main(String[] args) {
   Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
      
        int N= sc.nextInt();
            if (1<= N && N <=1000000) {
                System.out.println(N);
            } else {
                System.out.println("False");  
            }
  }
}